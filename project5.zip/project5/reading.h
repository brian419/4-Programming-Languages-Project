#ifndef _READING_H_
#define _READING_H_

#include <vector>
#include "Employee.h"

using namespace std;

vector<Employee*> *readFrom(string);

#endif